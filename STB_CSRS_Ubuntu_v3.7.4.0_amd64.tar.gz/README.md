# Splashtop Streamer (DEB, AMD64)


## Install

    sudo apt update
    sudo apt install ./Splashtop_Streamer_Ubuntu_amd64.deb

## Show command line usage

    splashtop-streamer help

## Deploy

    splashtop-streamer deploy $DEPLOYMENT_CODE

## Show configuration options

    splashtop-streamer config

## Uninstall

    sudo apt remove splashtop-streamer

## SRStreamer.service
### Status

    systemctl status SRStreamer.service

### Start

    sudo systemctl start SRStreamer.service

OR

    sudo service SRStreamer start

### Stop

    sudo systemctl stop SRStreamer.service

OR

    sudo service SRStreamer stop


